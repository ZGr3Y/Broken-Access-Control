let token = null;

async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    const data = await response.json();
    
    if (response.ok) {
        token = data.token;
        document.getElementById('login').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
        document.getElementById('tokenText').textContent = token; // Usa 'tokenText' per visualizzare il token
    } else {
        document.getElementById('loginMessage').textContent = data.message;
    }
}

async function accessAdmin() {
    const response = await fetch('/admin', {
        method: 'GET',
        headers: { 'Authorization': token }
    });

    const data = await response.json();

    if (response.ok) {
        document.getElementById('admin').style.display = 'block';
        document.getElementById('userList').innerHTML = data.users.map(user => `
            <p>
                ${user.username} 
                <button onclick="deleteUser('${user.username}')">Elimina</button>
            </p>
        `).join('');
    } else {
        document.getElementById('dashboardMessage').textContent = data.message;
    }
}

async function deleteUser(username) {
    const response = await fetch('/admin/delete-user', {
        method: 'DELETE',
        headers: { 
            'Authorization': token,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username })
    });

    const data = await response.json();

    if (response.ok) {
        document.getElementById('adminMessage').textContent = data.message;
        accessAdmin();  // Aggiorna la lista degli utenti dopo l'eliminazione
    } else {
        document.getElementById('adminMessage').textContent = data.message;
    }
}
