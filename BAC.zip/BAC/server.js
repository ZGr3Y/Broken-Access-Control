const express = require('express');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 3000;
const SECRET_KEY = ' ';
const HOST = '0.0.0.0';

app.use(express.json());
app.use(express.static('public'));

// Dati fittizi aggiornati per gli utenti
let users = [
    { username: 'giampaolo', password: 'adminpass', role: 'admin' },
    { username: 'paolo', password: 'password1', role: 'standard' },
    { username: 'sergio', password: 'password2', role: 'standard' }
];

// Endpoint di login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        const token = jwt.sign({ username: user.username, role: user.role }, SECRET_KEY);
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Credenziali non valide' });
    }
});

/* 
// Middleware di autenticazione con crittografia (firma controllo firma token)
function authenticate(req, res, next) {
    const token = req.headers['authorization'];

    if (token) {
        jwt.verify(token, SECRET_KEY, (err, decoded) => {
            if (err) {
                return res.status(403).json({ message: 'Token non valido' });
            } else {
                req.user = decoded;
                next();
            }
        });
    } else {
        res.status(401).json({ message: 'Token mancante' });
    }
}*/

function authenticate(req, res, next) {
    const token = req.headers['authorization'];

    if (token) {
        // Decodifica senza verifica (per scopi dimostrativi)
        const decoded = jwt.decode(token);  // Usa decode invece di verify
        req.user = decoded;
        next();
    } else {
        res.status(401).json({ message: 'Token mancante' });
    }
}


// Middleware di autorizzazione per ruolo
function authorize(role) {
    return (req, res, next) => {
        if (req.user.role === role) {
            next();
        } else {
            res.status(403).json({ message: 'Accesso negato' });
        }
    };
}

// Rotta protetta per la dashboard
app.get('/dashboard', authenticate, (req, res) => {
    res.json({ message: `Benvenuto, ${req.user.username}!` });
});

// Rotta protetta accessibile solo agli amministratori
app.get('/admin', authenticate, authorize('admin'), (req, res) => {
    res.json({ message: 'Area amministrativa', users: users.filter(u => u.role !== 'admin' || u.role =='admin') });
});

// Endpoint per eliminare un utente (solo per admin)
app.delete('/admin/delete-user', authenticate, authorize('admin'), (req, res) => {
    const { username } = req.body;
    
    // Controllo che l'utente non sia admin e esista
    const userIndex = users.findIndex(u => u.username === username && u.role !== 'admin');
    if (userIndex !== -1) {
        users.splice(userIndex, 1);  // Rimuove l'utente non admin
        res.json({ message: `Utente ${username} eliminato con successo.` });
    } else {
        res.status(400).json({ message: 'Utente non trovato o non autorizzato' });
    }
});

app.listen(PORT, HOST, () => {
    console.log(`Server in ascolto su http://${HOST}:${PORT}`);
});
